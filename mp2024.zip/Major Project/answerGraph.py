import networkx as nx
import matplotlib.pyplot as plt

# Define the relationships extracted from the text
relationships = [
    ('Rajendran', 'disowned', 'magnate'),
    ('Rajendran', 'disowned', 'magnate'),
    ('Rajendran', 'disowned', 'house'),
    ('he', 'refused', 'business'),
    ('he', 'refused', 'startup'),
    ('Vijay', 'arrives', 'house'),
    ('Vijay', 'arrives', 'disarray'),
    ('Vijay', 'invited', 'behest'),
    ('Vijay', 'invited', 'mother'),
    ('who', 'considers', 'him'),
    ('who', 'considers', 'son'),
    ('Jai', 'cheating', 'wife'),
    ('Jai', 'cheating', 'woman'),
    ('Jai', 'cheating', 'family'),
    ('Jai', 'cheating', 'daughter'),
    ('Rajendran', 'diagnosed', 'cancer'),
    ('Rajendran', 'diagnosed', 'months'),
    ('Rajendran', 'plans', 'birthday'),
    ('Rajendran', 'plans', 'manner'),
    ('Rajendran', 'plans', 'matters'),
    ('Rajendran', 'plans', 'celebration'),
    ('He', 'decides', 'condition'),
    ('He', 'decides', 'one'),
    ('He', 'decides', 'sons'),
    ('He', 'decides', 'successor'),
    ('He', 'decides', 'death'),
    ('he', 'is', 'money'),
    ('he', 'offers', 'secrets'),
    ('he', 'offers', 'rival'),
    ('Ajay', 'owes', 'amount'),
    ('Ajay', 'owes', 'money'),
    ('Ajay', 'owes', 'Mukesh')
]

# Create a directed graph to represent the relationships
G = nx.DiGraph()

# Add the edges with labels to the graph
for r in relationships:
    G.add_edge(r[0], r[2], label=r[1])

# Draw the graph with labels and save it as an image
pos = nx.spring_layout(G)  # Positioning algorithm for nodes
plt.figure(figsize=(12, 12))  # Set the figure size for better visualization
nx.draw_networkx_nodes(G, pos, node_size=1700, node_color='lightblue')
nx.draw_networkx_labels(G, pos, font_size=12)
nx.draw_networkx_edges(G, pos, edge_color='gray', arrowsize=25, width=3, arrowstyle='->')
nx.draw_networkx_edge_labels(G, pos, font_size=10, edge_labels=nx.get_edge_attributes(G, 'label'))

# Hide the axis and display the graph
plt.axis('off')
plt.show()
