import stanza

# Download the English model for Stanza (only needs to be done once)
# stanza.download('en')  # Uncomment this line if you haven't downloaded the model yet

# Load the English model in Stanza
nlp = stanza.Pipeline('en')

# Define the input text
text = "Ben lived in a small village near the forest. One day, while walking through the woods, he found a glowing stone. When he touched it, a voice said, Thank you. You are now the guardian of the forest.Ben was surprised but happy. From then on, he could talk to animals and plants. He helped the trees grow and kept the forest safe. The animals loved him, and the village became peaceful. Ben smiled, knowing he was helping the forest and everyone around him."
# Process the text using Stanza
doc = nlp(text)

# Extract entities and relationships
entities = []
relationships = []

# Extract entities from the document
for ent in doc.ents:
    entities.append((ent.text, ent.type))

# Extract subject-verb-object triples from the sentences
for sent in doc.sentences:
    subject = None
    verb = None
    obj = None
    for word in sent.words:
        # Check if word.deps is not None and then check for subject
        if word.deps and 'nsubj' in word.deps:
            subject = word.text
        # Check if word.deps is not None and then check for object
        if word.deps and 'dobj' in word.deps:
            obj = word.text
        # Check for verb (main verb of the sentence)
        if word.deprel == 'root':
            verb = word.text
        # If subject, verb, and object are identified, add the relationship
        if subject and verb and obj:
            relationships.append((subject, verb, obj))
            subject = None  # Reset for the next relationship
            obj = None

# Print the extracted entities and relationships
print('Entities:', entities)
print('Relationships:', relationships)
