import nltk
from nltk.corpus import stopwords
from nltk.cluster.util import cosine_distance
import numpy as np
import networkx as nx

# Ensure necessary NLTK data is downloaded
nltk.download('stopwords')
nltk.download('punkt')


def read_article(file_name: str) -> list:
    """Reads the article from a given file and tokenizes it into sentences."""
    try:
        with open(file_name, "r") as file:
            filedata = file.readlines()

        if not filedata:  # Handle empty files
            print(f"Error: The file '{file_name}' is empty.")
            return []

        article = " ".join(filedata)  # Join all lines in case the file spans multiple lines
        sentences = nltk.sent_tokenize(article)  # Use NLTK's sentence tokenizer

        # Tokenize each sentence into words
        sentences = [sentence.split(" ") for sentence in sentences]
        return sentences

    except FileNotFoundError:
        print(f"Error: The file '{file_name}' was not found.")
        return []


def sentence_similarity(sent1: list, sent2: list, stopwords: set = None) -> float:
    """Calculates the cosine similarity between two sentences."""
    if stopwords is None:
        stopwords = set()

    # Convert sentences to lowercase and remove stopwords
    sent1 = [w.lower() for w in sent1]
    sent2 = [w.lower() for w in sent2]

    all_words = list(set(sent1 + sent2))

    # Create vectors for the two sentences
    vector1 = [0] * len(all_words)
    vector2 = [0] * len(all_words)

    for w in sent1:
        if w in stopwords:
            continue
        vector1[all_words.index(w)] += 1

    for w in sent2:
        if w in stopwords:
            continue
        vector2[all_words.index(w)] += 1

    similarity = 1 - cosine_distance(vector1, vector2)
    if np.isnan(similarity):  # Handle zero vectors
        return 0
    return similarity


def gen_sim_matrix(sentences: list, stop_words: set) -> np.ndarray:
    """Generates a similarity matrix for the sentences."""
    similarity_matrix = np.zeros((len(sentences), len(sentences)))

    for idx1 in range(len(sentences)):
        for idx2 in range(len(sentences)):
            if idx1 == idx2:
                continue
            similarity_matrix[idx1][idx2] = sentence_similarity(sentences[idx1], sentences[idx2], stop_words)

    return similarity_matrix


def generate_summary(file_name: str, top_n: int = 5) -> str:
    """Generates the summary of the text in the given file."""
    stop_words = set(stopwords.words('english'))
    summarize_text = []

    sentences = read_article(file_name)

    if not sentences:
        return "Error: No valid sentences found in the file."

    sentence_similarity_matrix = gen_sim_matrix(sentences, stop_words)

    # Create a similarity graph from the matrix
    sentence_similarity_graph = nx.from_numpy_array(sentence_similarity_matrix)

    # Apply PageRank to score the sentences
    scores = nx.pagerank(sentence_similarity_graph)

    # Rank sentences based on their scores
    ranked_sentence = sorted(((scores[i], s) for i, s in enumerate(sentences)), reverse=True)

    # Get the top N sentences for the summary
    for i in range(min(top_n, len(ranked_sentence))):
        summarize_text.append(" ".join(ranked_sentence[i][1]))

    # Return the summary
    return ". ".join(summarize_text)


# Example usage - replace 'msft.txt' with the correct path to your file
generate_summary("msft.txt", top_n=9)
